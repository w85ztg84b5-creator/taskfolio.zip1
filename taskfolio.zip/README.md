# Taskfolio

Taskfolio is a Next.js App Router project with a responsive dashboard for discovering and tracking example social microtasks. It links to FoxiGrow and Paragram's official sites. Example tasks are not live offers or earnings guarantees.

## Run locally

Use Node.js 20.9 or newer, then run:

```bash
npm install
npm run dev
```

Open `http://localhost:3000`.

## Deploy on Vercel

Import this repository into Vercel with the project root set to the repository root. Vercel detects Next.js from `package.json`; the build command is `npm run build` and the output is managed by Next.js.

## Publish on GitHub

Create a GitHub repository, then run from this folder:

```bash
git init
git add .
git commit -m "Create Taskfolio Next.js dashboard"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
git push -u origin main
```

The checklist is saved in the current browser only. Check each platform's rules, availability, and payment terms before participating.
