import "./styles.css";

export const metadata = {
  title: "Taskfolio — Small tasks, on your terms",
  description: "A simple personal dashboard for finding and tracking social microtasks.",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
