export default function Home() {
  return (
    <main className="preview">
      <iframe
        className="dashboard"
        src="/dashboard.html"
        title="Taskfolio task dashboard"
      />
    </main>
  );
}
