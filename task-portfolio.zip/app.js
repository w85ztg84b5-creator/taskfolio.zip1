const cards = [...document.querySelectorAll(".task-card")];
const filters = [...document.querySelectorAll(".filter-chip")];
const search = document.getElementById("taskSearch");
const emptyState = document.getElementById("emptyState");
const savedCount = document.getElementById("savedCount");
const STORAGE_KEY = "small-hours-saved-tasks-v1";
let activeFilter = "all";
let saved = new Set();

try {
  saved = new Set(JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]"));
} catch {
  saved = new Set();
}

function updateSaveButtons() {
  cards.forEach((card) => {
    const button = card.querySelector(".save-button");
    const isSaved = saved.has(card.dataset.id);
    button.setAttribute("aria-pressed", String(isSaved));
    button.textContent = isSaved ? "♥" : "♡";
  });
  savedCount.textContent = String(saved.size).padStart(2, "0");
}

function applyFilters() {
  const query = search.value.trim().toLowerCase();
  let shown = 0;
  cards.forEach((card) => {
    const tagMatch = activeFilter === "all" ||
      (activeFilter === "saved" ? saved.has(card.dataset.id) : card.dataset.tags.split(" ").includes(activeFilter));
    const textMatch = !query || `${card.dataset.search} ${card.textContent}`.toLowerCase().includes(query);
    const visible = tagMatch && textMatch;
    card.hidden = !visible;
    if (visible) shown += 1;
  });
  emptyState.hidden = shown > 0;
}

filters.forEach((button) => {
  button.addEventListener("click", () => {
    activeFilter = button.dataset.filter;
    filters.forEach((item) => {
      const selected = item === button;
      item.classList.toggle("is-selected", selected);
      item.setAttribute("aria-pressed", String(selected));
    });
    applyFilters();
  });
});

cards.forEach((card) => {
  card.querySelector(".save-button").addEventListener("click", () => {
    const id = card.dataset.id;
    if (saved.has(id)) saved.delete(id);
    else saved.add(id);
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify([...saved])); } catch { /* Saving remains available for this page view. */ }
    updateSaveButtons();
    applyFilters();
  });
});

search.addEventListener("input", applyFilters);
updateSaveButtons();
applyFilters();
