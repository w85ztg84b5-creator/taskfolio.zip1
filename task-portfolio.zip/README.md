# Small Hours — task portfolio

A responsive, static task-discovery portfolio. It has no build step, backend, API keys, or database. The examples are categories advertised by FoxiGrow and Paragram, not a live feed of available work. Search, category filters, and saved examples run in the browser; saved items stay in local storage on the current device.

## Preview locally

Open `index.html` in a browser. For a local development server, run:

```bash
python -m http.server 8000
```

Then visit <http://localhost:8000>.

## Publish with GitHub and Vercel

1. Create a GitHub repository and upload the contents of this folder (put `index.html` at the repository root).
2. In Vercel, choose **Add New → Project**, import that GitHub repository, and deploy it as a static site. No build command or output directory is needed.
3. Future pushes to the connected branch will trigger a new deployment.

You can also deploy with Vercel CLI from this folder using `vercel`.

## Edit the site

- `index.html` contains the page and task examples.
- `styles.css` contains the layout, colors, and responsive styling.
- `app.js` contains search, category filters, and saved examples.
- `vercel.json` enables clean URLs; the static site works without a framework.

## Important

Task availability, eligibility, rewards, and withdrawal terms change. This page does not verify provider claims or guarantee earnings. Check the provider's current terms and each social network's rules before participating. For example, YouTube says it prohibits engagement whose sole purpose is financial gain, and TikTok restricts fake or financially incentivized engagement. Never share passwords, one-time codes, recovery phrases, or private wallet keys for a task.
